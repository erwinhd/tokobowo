<?php
header("Content-type: application/vnd.ms-excel;charset:UTF-8");
header("Content-type: application/image/png");
header("Content-Disposition: attachment; filename=Daftar User.xls");

?>
<table width="100%" border="0" cellpadding="2" cellspacing="0">
			<thead>
				<tr>
				 	
				 	<td colspan="5" align="center">
				 		<h1 style="margin:0">Toko Bowo Elektronik</h1>
				 		<h4 style="margin:0;margin-top:4px;">Jl. Warakas 6 No.76, Jakarta</h4>
				 	</td>
				</tr>
				
				<tr><td colspan="7"><hr></td></tr>
				
				<tr>
				 	<td colspan="7" align="center"><h3 align="center">Daftar User</h3></td>
				</tr>

				<tr>
					<th width="5%" style="border:1px solid black">No.</th>
					<th width="20%" style="border:1px solid black">Nama</th>
					<th style="border:1px solid black">Alamat</th>
					<th width="20%" style="border:1px solid black">HP</th>
					<th width="15%" style="border:1px solid black">Jabatan</th>
				</tr>
			</thead>
			<tbody>
									<tr>
						<td align="center" style="border:1px solid black">1.</td>
						<td align="center" style="border:1px solid black">admin</td>
						<td align="center" style="border:1px solid black">Jl. Warakas 1</td>
						<td align="center" style="border:1px solid black">0881025533055</td>
						<td align="center" style="border:1px solid black">Admin</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">2.</td>
						<td align="center" style="border:1px solid black">Ahmad Abdul</td>
						<td align="center" style="border:1px solid black">Jl. Warakas 6</td>
						<td align="center" style="border:1px solid black">085770851631</td>
						<td align="center" style="border:1px solid black">Manager</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">3.</td>
						<td align="center" style="border:1px solid black">Erwin Catur Prasetyo</td>
						<td align="center" style="border:1px solid black">Jl. Warakas 1 No.70 RT /RW 012/001</td>
						<td align="center" style="border:1px solid black">08981606324</td>
						<td align="center" style="border:1px solid black">Admin</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">4.</td>
						<td align="center" style="border:1px solid black">Kasir</td>
						<td align="center" style="border:1px solid black">Warakas</td>
						<td align="center" style="border:1px solid black">085770851630</td>
						<td align="center" style="border:1px solid black">Kasir</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">5.</td>
						<td align="center" style="border:1px solid black">Manager</td>
						<td align="center" style="border:1px solid black">Warakas 6</td>
						<td align="center" style="border:1px solid black">085770851636</td>
						<td align="center" style="border:1px solid black">Manager</td>
					</tr>
							</tbody>
		</table>