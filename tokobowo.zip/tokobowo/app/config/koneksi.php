<?php 
	$host = "localhost"; 
	$username = "id20278017_erwin";
	$password = "4Yqwj^[gK<HJ*BiG"; 
	$database = "id20278017_tokobowo";
	mysql_connect($host,$username,$password) or die ("Harap Periksa Koneksi Database Anda!");
	mysql_select_db($database) or die ("Database Tidak Ditemukan!");
?>