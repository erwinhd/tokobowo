<?php
header("Content-type: application/vnd.ms-excel;charset:UTF-8");
header("Content-type: application/image/png");
header("Content-Disposition: attachment; filename=Laporan Barang Laris.xls");

?>
<table width="100%" border="0" cellpadding="2" cellspacing="0">
			<thead>
				<tr>
				 	
				 	<td colspan="15" align="center">
				 		<h1 style="margin:0">Toko Bowo Elektronik</h1>
				 		<h4 style="margin:0;margin-top:4px;">Jl. Warakas 6 No.76, Jakarta</h4>
				 	</td>
				</tr>
				<tr><td colspan="15"><hr></td></tr>
				<tr>
				 	<td colspan="15" align="center"><h3 align="center">Laporan Barang Laris</h3></td>
				</tr>
				<tr>
					<th width="5%" style="border:1px solid black">No.</th>
					<th width="12%" style="border:1px solid black">Kode</th>
					<th width="23%" style="border:1px solid black">Nama Barang</th>
					<th style="border:1px solid black">Harga Jual</th>
					<th style="border:1px solid black">Jumlah</th>
					<th style="border:1px solid black">Total Harga</th>
				</tr>
			</thead>
			<tbody>
									<tr>
						<td align="center" style="border:1px solid black">1.</td>
						<td align="center" style="border:1px solid black">BRG000029</td>
						<td align="center" style="border:1px solid black">Kabel antena RG6 Belden</td>
						<td align="right" style="border:1px solid black">4.950</td>
						<td align="right" style="border:1px solid black">5</td>
						<td align="right" style="border:1px solid black">24.750</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">2.</td>
						<td align="center" style="border:1px solid black">BRG000023</td>
						<td align="center" style="border:1px solid black">Splitter antena 2 Way</td>
						<td align="right" style="border:1px solid black">18.700</td>
						<td align="right" style="border:1px solid black">2</td>
						<td align="right" style="border:1px solid black">37.400</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">3.</td>
						<td align="center" style="border:1px solid black">BRG000030</td>
						<td align="center" style="border:1px solid black">setrika maspion</td>
						<td align="right" style="border:1px solid black">165.000</td>
						<td align="right" style="border:1px solid black">2</td>
						<td align="right" style="border:1px solid black">330.000</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">4.</td>
						<td align="center" style="border:1px solid black">BRG000011</td>
						<td align="center" style="border:1px solid black">Gongniu Stop Kontak 4 lubang 1on-off kabel 1,5 mtr</td>
						<td align="right" style="border:1px solid black">88.000</td>
						<td align="right" style="border:1px solid black">1</td>
						<td align="right" style="border:1px solid black">88.000</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">5.</td>
						<td align="center" style="border:1px solid black">BRG000002</td>
						<td align="center" style="border:1px solid black">Antena tv digital OUTDOOR dan analog LUAR PF HDU 2</td>
						<td align="right" style="border:1px solid black">198.000</td>
						<td align="right" style="border:1px solid black">1</td>
						<td align="right" style="border:1px solid black">198.000</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">6.</td>
						<td align="center" style="border:1px solid black">BRG000012</td>
						<td align="center" style="border:1px solid black">Advance : Speaker T-101</td>
						<td align="right" style="border:1px solid black">165.000</td>
						<td align="right" style="border:1px solid black">1</td>
						<td align="right" style="border:1px solid black">165.000</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">7.</td>
						<td align="center" style="border:1px solid black">BRG000005</td>
						<td align="center" style="border:1px solid black">EVINIX Set Top Box H-1</td>
						<td align="right" style="border:1px solid black">220.000</td>
						<td align="right" style="border:1px solid black">1</td>
						<td align="right" style="border:1px solid black">220.000</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">8.</td>
						<td align="center" style="border:1px solid black">BRG000006</td>
						<td align="center" style="border:1px solid black">Luby DVB T2-01</td>
						<td align="right" style="border:1px solid black">165.000</td>
						<td align="right" style="border:1px solid black">1</td>
						<td align="right" style="border:1px solid black">165.000</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">9.</td>
						<td align="center" style="border:1px solid black">BRG000009</td>
						<td align="center" style="border:1px solid black">Bohlam Philips Essential Energy Saver 14W E27 </td>
						<td align="right" style="border:1px solid black">35.200</td>
						<td align="right" style="border:1px solid black">1</td>
						<td align="right" style="border:1px solid black">35.200</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">10.</td>
						<td align="center" style="border:1px solid black">BRG000010</td>
						<td align="center" style="border:1px solid black">Bohlam Philips Tornado Energy Saver 20W E27 </td>
						<td align="right" style="border:1px solid black">48.400</td>
						<td align="right" style="border:1px solid black">1</td>
						<td align="right" style="border:1px solid black">48.400</td>
					</tr>
							</tbody>
		</table>