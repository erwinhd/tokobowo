<?php
header("Content-type: application/vnd.ms-excel;charset:UTF-8");
header("Content-type: application/image/png");
header("Content-Disposition: attachment; filename=Daftar Supplier.xls");

?>
<table width="100%" border="0" cellpadding="2" cellspacing="0">
			<thead>
				<tr>
				 	
				 	<td colspan="5" align="center">
				 		<h1 style="margin:0">Toko Bowo Elektronik</h1>
				 		<h4 style="margin:0;margin-top:4px;">Jl. Warakas 6 No.76, Jakarta</h4>
				 	</td>
				</tr>
				
				<tr><td colspan="7"><hr></td></tr>
				
				<tr>
				 	<td colspan="7" align="center"><h3 align="center">Daftar Supplier</h3></td>
				</tr>

				<tr>
					<th width="5%" style="border:1px solid black">No.</th>
					<th width="12%" style="border:1px solid black">Kode</th>
					<th width="23%" style="border:1px solid black">Nama</th>
					<th style="border:1px solid black">Alamat</th>
					<th width="18%" style="border:1px solid black">Telepon</th>
				</tr>
			</thead>
			<tbody>
									<tr>
						<td align="center" style="border:1px solid black">1.</td>
						<td align="center" style="border:1px solid black">SPL018</td>
						<td align="center" style="border:1px solid black">Advance Digitals Official</td>
						<td align="center" style="border:1px solid black">Jl Sunter agung timur Blok 01 No.18-19, Jakarta</td>
						<td align="center" style="border:1px solid black">0831-9794-872</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">2.</td>
						<td align="center" style="border:1px solid black">SPL015</td>
						<td align="center" style="border:1px solid black">Ali Elektronik</td>
						<td align="center" style="border:1px solid black">Jl. Benteng Betawi No.5 Kota Tangerang</td>
						<td align="center" style="border:1px solid black">0219212178</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">3.</td>
						<td align="center" style="border:1px solid black">SPL022</td>
						<td align="center" style="border:1px solid black">Elektronesia</td>
						<td align="center" style="border:1px solid black">Pejaten Barat 2 Jl.timbul, Jakarta Selatan,</td>
						<td align="center" style="border:1px solid black">0838-1199-808</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">4.</td>
						<td align="center" style="border:1px solid black">SPL020</td>
						<td align="center" style="border:1px solid black">PT Star Cosmos</td>
						<td align="center" style="border:1px solid black">Jl. Rawa Buaya No.8, Kecamatan Cengkareng, Kota Jakarta Barat</td>
						<td align="center" style="border:1px solid black">0215439663</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">5.</td>
						<td align="center" style="border:1px solid black">SPL014</td>
						<td align="center" style="border:1px solid black">PT. BEST FORTUNE INDONESIA</td>
						<td align="center" style="border:1px solid black">Jl. terusan hibrida, Blok GOS/B2 Kelapa Gading-Jakarta utara</td>
						<td align="center" style="border:1px solid black">0212906873</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">6.</td>
						<td align="center" style="border:1px solid black">SPL016</td>
						<td align="center" style="border:1px solid black">PT. Gunung Semesta</td>
						<td align="center" style="border:1px solid black">Jl. Mangga Dua Raya No.8, RT.17/RW.11</td>
						<td align="center" style="border:1px solid black">0216264525</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">7.</td>
						<td align="center" style="border:1px solid black">SPL017</td>
						<td align="center" style="border:1px solid black">PT. Indokom</td>
						<td align="center" style="border:1px solid black">Jl. KH. Hasyim Ashari No.125, Jakarta Pusat</td>
						<td align="center" style="border:1px solid black">021-63855981</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">8.</td>
						<td align="center" style="border:1px solid black">SPL021</td>
						<td align="center" style="border:1px solid black">Sekai Roxy</td>
						<td align="center" style="border:1px solid black">Jl. KH. Hasyim Ashari No.35A, RT.1/RW.11, Cideng, Kecamatan Gambir, Kota Jakarta Pusat</td>
						<td align="center" style="border:1px solid black">0216323325</td>
					</tr>
									<tr>
						<td align="center" style="border:1px solid black">9.</td>
						<td align="center" style="border:1px solid black">SPL019</td>
						<td align="center" style="border:1px solid black">Toko Sumber Lampu</td>
						<td align="center" style="border:1px solid black">GLODOK Lt.2 Blok B3 No.2, Hayam Wuruk St No.127, Mangga Besar, Jakarta</td>
						<td align="center" style="border:1px solid black">0216232105</td>
					</tr>
							</tbody>
		</table>